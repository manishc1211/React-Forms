import { s as sc, f as cc, R as Rm, h as Oa, i as Wa, o as oc, l as ac, p as ha, x as qi, z as Gi, D as ic } from '../profile-hook-794bbcb2.js';
import { W as WD, Y as Yn } from '../App-8881a231.js';

function h(t){Wa(t,"svelte-1onuouz","html,body{height:100%;width:100%}:root{--drawer-width:256px;--app-content-width:calc(100% - 260px);--top-bar-height:48px;--top-bar-width:calc(100% - 255px)}");}function l(t){let s,a;return s=new WD({props:{isFullscreen:!0}}),{c(){oc(s.$$.fragment);},m(t,o){ac(s,t,o),a=!0;},p:ha,i(t){a||(qi(s.$$.fragment,t),a=!0);},o(t){Gi(s.$$.fragment,t),a=!1;},d(t){ic(s,t);}}}function m(t){return Yn.set(!0),[]}Rm();const b=new class extends sc{constructor(t){super(),cc(this,t,m,l,Oa,{},h);}}({target:document.body});

export { b as default };
